app.controller('departmentMatrixCtrl', function($scope, $rootScope, $uibModal, $interval, $location, $http, $filter) {
      $scope.deptAssignments = [];
      $scope.sortType     = 'name'; // set the default sort type
      $scope.sortReverse  = false;  // set the default sort order
      $scope.searchFish   = '';     // set the default search/filter term
    
      $scope.viewby = "5";
	  $scope.totalItems = $scope.deptAssignments.length;
	  $scope.currentPage = 1;
	  $scope.itemsPerPage = $scope.viewby;
      $scope.maxSize = 3; //Number of pager buttons to show
      
      $scope.removalList = "";
      $scope.addList = "";

	  $scope.setPage = function (pageNo) {
		$scope.currentPage = pageNo;
	  };

	  $scope.pageChanged = function() {
		console.log('Page changed to: ' + $scope.currentPage);
	  };

	$scope.setItemsPerPage = function(num) {
	  $scope.itemsPerPage = num;
	  $scope.currentPage = 1; //reset to first page
	}

    $scope.getDeptAssignments = function(){    
        $rootScope.loading = true;
        $scope.deptAssignments = [
            {
                "id": "2",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "12345",
                "prev_doc_number": "Prev 12345",
                "name": "a"
            },
            {
                "id": "20",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "123456",
                "prev_doc_number": "Prev 123456",
                "name": "b"
            },
            {
                "id": "3",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "123457",
                "prev_doc_number": "aPrev 123457",
                "name": "c"
            },
            {
                "id": "4",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "123457",
                "prev_doc_number": "aPrev 123457",
                "name": "d"
            }
            ,
            {
                "id": "5",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "123457",
                "prev_doc_number": "aPrev 123457",
                "name": "e"
            },
            {
                "id": "6",
                "DepartmentCode": "MM",
                "DepartmentName": "MM",
                "TrainingNumber": "123457",
                "prev_doc_number": "aPrev 123457",
                "name": "f"
            }
        ]
        $scope.deptAssignmentsBackup = $scope.deptAssignments.slice(0);
        $scope.totalItems = $scope.deptAssignments.length; 
        $interval(function(){
            $rootScope.loading = false;
        }, 1000);      
        
    }

    $scope.getDeptAssignments();

    $scope.updateRemovalList = function(elem){

        var index = $scope.deptAssignments.indexOf(elem);
        if (index > -1) {
            $scope.deptAssignments.splice(index, 1);
            $scope.totalItems = $scope.deptAssignments.length;
        }

        if(!$scope.removalList)
            $scope.removalList = elem.id;
        else $scope.removalList += "," + elem.id;
        debugger;
    }

    $scope.saveDeptAssigns = function(){
        $rootScope.loading = true;
        var add = $scope.addList;
        var remove = $scope.removalList;
        var deptCode = $location.search().DepartmentCode;

        var data = {
            DepartmentCode: deptCode,
            New: add,
            Remove: remove
        }

        if(add || remove){
            //if there is data only then save.
            $http({
                url: '/api/MatrixDepartment/',
                dataType: 'json',
                method: 'POST',
                data: data,
                headers: {
                    "Content-Type": "application/json"
                }
            
            }).success(function(response){
                $rootScope.loading = false;
                alert('Saved successfull!');

            }).error(function(error){
                $rootScope.loading = false;
                alert('Something went wrong!');
            });
        }

        $interval(function(){
            $rootScope.loading = false;
        }, 1000);  
        debugger;
    }

    $scope.resetDeptAssigns = function(){
        $scope.removalList = "";
        $scope.addList = "";
        $scope.searchFish = "";
        $scope.addListDetailed = [];
        $scope.getDeptAssignments();
    }

    $scope.addDeptTraining = function(){
        //$scope.addList = "";
        $scope.addListDetailed = [];
        var modalInstance = $uibModal.open({
            templateUrl: 'modal1.html',
            size: 'lg',
            controller: 'departmentMatrixModalCtrl'
          });

          modalInstance.result.then(function (response) {
              $scope.addListDetailed = response.addListDetailed;
              angular.forEach($scope.addListDetailed, function(value, key){
                  var alreadyPresent = false;
                  angular.forEach($scope.deptAssignments, function(value2, key){
                      if(value.id == value2.id)
                        alreadyPresent = true;
                  });
                  debugger;
                  if (!alreadyPresent){
                    $scope.deptAssignments.push(value);
                    $scope.deptAssignmentsBackup.push(value);
                    //
                      if(!$scope.addList)
                         $scope.addList += value.id; 
                      else
                         $scope.addList +=  "," + value.id; 
                    //
                  }
              });
              $scope.totalItems = $scope.deptAssignments.length;

          }, function (dismissed) {
              debugger;
          });
        
    }

    $scope.searchTriggered = function(){
        $scope.searchFish;
        $scope.deptAssignmentsBackup;

        var keyword = $scope.searchFish.toLowerCase();
        $scope.deptAssignments = $scope.deptAssignmentsBackup.filter(function (da) {
            debugger;
            return (da.name.toLowerCase().indexOf(keyword) > -1 
                || da.prev_doc_number.toLowerCase().indexOf(keyword) > -1
                || da.TrainingNumber.toLowerCase().indexOf(keyword) > -1
                || da.DepartmentName.toLowerCase().indexOf(keyword) > -1
                || da.DepartmentCode.toLowerCase().indexOf(keyword) > -1
            );
        });
        $scope.totalItems = $scope.deptAssignments.length; 
        debugger;
    }

    $scope.sortTriggered = function(column){
        $scope.sortReverse = !$scope.sortReverse;
        $scope.sortType = column;
        $scope.deptAssignments = $filter('orderBy')($scope.deptAssignments, column, $scope.sortReverse);
    }

    $scope.resetConfirm = function(){
        var r = confirm("Clicking OK will reset all changes!");
        if (r == true) {
            $scope.resetDeptAssigns();
        } 
    }

    $scope.saveConfirm = function(){
        var r = confirm("Click OK to save all changes!");
        if (r == true) {
            $scope.saveDeptAssigns();
        } 
    }

    $scope.auditTrail = function(item){
        debugger;
        // $http({
        //     url: '/api/auditTrail/',
        //     dataType: 'json',
        //     method: 'GET',
        //     headers: {
        //         "Content-Type": "application/json"
        //     }
        
        // }).success(function(response){
        //     $rootScope.loading = false;

        // }).error(function(error){
        //     $rootScope.loading = false;
        //     alert('Something went wrong!');
        // });

        $scope.auditTrailData = [
            {
                id: "1",
                objectType: "EMPLOYEE",
                objectCode: "123",
                operationType: "NEW",
                createdBy: "SYSTEM",
                created: "2018-06-18T10:23:13",
                description: "line1<br>line2<br>"
            }

        ];

        angular.forEach($scope.auditTrailData, function(value, key){
            value.description = value.description.replace(/<br\s*\/?>/mg,"\n");
        });


        var modalInstance = $uibModal.open({
            templateUrl: 'auditTrailModal.html',
            size: 'lg',
            scope: $scope
          });
    }


});


//iiii
app.controller('departmentMatrixModalCtrl', function($scope, $uibModalInstance, $rootScope, $interval, $location, $filter) {
    $scope.newDeptTrainings = [];
    $scope.addListDetailed = [];
    $scope.saveNewDeptTraining = function(){
        angular.forEach($scope.newDeptTrainings, function(value, key){
            if(!$scope.addList && value.isChecked)
                $scope.addList = value.id;
            else if(value.isChecked)
                $scope.addList += ',' + value.id;
       });

        var response = {
            addList: $scope.addList,
            addListDetailed: $scope.addListDetailed
        }
        $uibModalInstance.close(response);
    }
    $scope.cancel = function(){
        $scope.addList = "";
        $uibModalInstance.dismiss('cancel');
    }
    $scope.getNewDeptTrainings = function(){
        $rootScope.loading = true;
        $scope.newDeptTrainings = [
            {
                "id": "2352",
                "majorVersion": "0",
                "number": "123459",
                "name": "Title of doc 12345",
                "prev_doc_number": "Prev 12345"
            },
            {
                "id": "2353",
                "majorVersion": "10",
                "number": "12345",
                "name": "Title of doc 12346",
                "prev_doc_number": "Prev 12346"
            },
            {
                "id": "2354",
                "majorVersion": "1",
                "number": "12345",
                "name": "Title of doc 12347",
                "prev_doc_number": "Prev 12347"
            }
        ]    
        $scope.newDeptTrainingsBackup = $scope.newDeptTrainings.slice(0);
        $scope.totalItems = $scope.newDeptTrainings.length;  
        $interval(function(){
            $rootScope.loading = false;
        }, 1000);    
    }

    $scope.getNewDeptTrainings();

      $scope.sortType     = 'name'; // set the default sort type
      $scope.sortReverse  = false;  // set the default sort order
      $scope.searchFish   = '';     // set the default search/filter term
    
      $scope.viewby = "5";
	  $scope.totalItems = $scope.newDeptTrainings.length;
	  $scope.currentPage = 1;
	  $scope.itemsPerPage = $scope.viewby;
      $scope.maxSize = 3; //Number of pager buttons to show
      
      $scope.addList = "";

	  $scope.setPage = function (pageNo) {
		$scope.currentPage = pageNo;
	  };

	  $scope.pageChanged = function() {
		console.log('Page changed to: ' + $scope.currentPage);
	  };

	$scope.setItemsPerPage = function(num) {
	  $scope.itemsPerPage = num;
	  $scope.currentPage = 1; //reset to first page
    }

    $scope.searchTriggered = function(){
        $scope.searchFish;
        $scope.getNewDeptTrainingsBackup;
        var keyword = $scope.searchFish.toLowerCase();
        $scope.newDeptTrainings = $scope.newDeptTrainingsBackup.filter(function (da) {
            return (da.toLowerCase().name.indexOf(keyword) > -1 
                || da.toLowerCase().prev_doc_number.indexOf(keyword) > -1
                || da.toLowerCase().number.indexOf(keyword) > -1
                || da.toLowerCase().majorVersion.indexOf(keyword) > -1
            );
        });
        $scope.totalItems = $scope.newDeptTrainings.length; 
        debugger;
    }

    $scope.sortTriggered = function(column){
        $scope.sortReverse = !$scope.sortReverse;
        $scope.sortType = column;
        $scope.newDeptTrainings = $filter('orderBy')($scope.newDeptTrainings, column, $scope.sortReverse);
    }


    $scope.addDetailed = function(newDeptObj){
        if(newDeptObj.isChecked){
            var deptCode = $location.search().DepartmentCode;
            debugger;
            var obj = {
                id: newDeptObj.id,
                DepartmentCode: deptCode? deptCode : "querystring missing",
                DepartmentName: "",
                TrainingNumber: newDeptObj.number,
                prev_doc_number: newDeptObj.prev_doc_number,
                name: newDeptObj.name,
                isNew: true
            }
            $scope.addListDetailed.push(obj);

        }
    }
    


});
