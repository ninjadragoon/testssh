app.controller('positionMatrixCtrl', function($scope, $rootScope, $uibModal, $interval, $location, $http, $filter) {

    $scope.trainingAssigns = [];
    $scope.sortType     = 'name'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term
  
    $scope.viewby = "5";
    $scope.totalItems = $scope.trainingAssigns.length;
    $scope.currentPage = 1;
    $scope.itemsPerPage = $scope.viewby;
    $scope.maxSize = 3; //Number of pager buttons to show
    
    $scope.removalList = "";
    $scope.addList = "";

    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };

    $scope.pageChanged = function() {
      console.log('Page changed to: ' + $scope.currentPage);
    };

  $scope.setItemsPerPage = function(num) {
    $scope.itemsPerPage = num;
    $scope.currentPage = 1; //reset to first page
  }


  $scope.updateRemovalList = function(elem){

      var index = $scope.trainingAssigns.indexOf(elem);
      if (index > -1) {
          $scope.trainingAssigns.splice(index, 1);
          $scope.totalItems = $scope.trainingAssigns.length;
      }

      if(!$scope.removalList)
          $scope.removalList = elem.id;
      else $scope.removalList += "," + elem.id;
      debugger;
  }

  $scope.saveDeptAssigns = function(){
      $rootScope.loading = true;
      var add = $scope.addList;
      var remove = $scope.removalList;
      var positionCode = $scope.selectedDeptPos;

      var data = {
        PositionCode: positionCode,
        New: add,
        Remove: remove
     }

     debugger;

     if(add || remove){
        //if there is data only then save.
        $http({
            url: '/api/MatrixPosition/',
            dataType: 'json',
            method: 'POST',
            data: data,
            headers: {
                "Content-Type": "application/json"
            }
        
        }).success(function(response){
            $rootScope.loading = false;
            alert('Saved successfull!');

        }).error(function(error){
            $rootScope.loading = false;
            alert('Something went wrong!');
        });
    }

      $interval(function(){
          $rootScope.loading = false;
      }, 1000);  
  }

  $scope.resetDeptAssigns = function(){
      $scope.removalList = "";
      $scope.addList = "";
      $scope.searchFish = "";
      $scope.addListDetailed = [];
      $scope.getTrainingAssigns();
  }

  $scope.addDeptTraining = function(){
      //$scope.addList = "";
      $scope.addListDetailed = [];
      var modalInstance = $uibModal.open({
          templateUrl: 'modal1.html',
          size: 'lg',
          controller: 'positionMatrixModalCtrl'
        });

        modalInstance.result.then(function (response) {
            //$scope.addList = response.addList; 
            $scope.addListDetailed = response.addListDetailed;
            angular.forEach($scope.addListDetailed, function(value, key){
                var alreadyPresent = false;
                angular.forEach($scope.trainingAssigns, function(value2, key){
                    if(value.id == value2.id)
                      alreadyPresent = true;
                });
                debugger;
                if (!alreadyPresent){
                  $scope.trainingAssigns.push(value);
                  $scope.trainingAssignsBackup.push(value);
                  //
                  if(!$scope.addList)
                    $scope.addList += value.id; 
                  else
                    $scope.addList +=  "," + value.id; 
                  //
                }
            });
            $scope.totalItems = $scope.trainingAssigns.length;

        }, function (dismissed) {
            debugger;
        });
      
  }

  $scope.searchTriggered = function(){
      $scope.searchFish;
      $scope.trainingAssignsBackup;
      var keyword = $scope.searchFish.toLowerCase();
      $scope.trainingAssigns = $scope.trainingAssignsBackup.filter(function (da) {
          return (da.name.toLowerCase().indexOf(keyword) > -1 
              || da.prev_doc_number.toLowerCase().indexOf(keyword) > -1
              || da.TrainingNumber.toLowerCase().indexOf(keyword) > -1
              || da.DepartmentName.toLowerCase().indexOf(keyword) > -1
              || da.DepartmentCode.toLowerCase().indexOf(keyword) > -1
          );
      });
      $scope.totalItems = $scope.trainingAssignsBackup.length; 
      debugger;
  }

  $scope.sortTriggered = function(column){
    $scope.sortReverse = !$scope.sortReverse;
    $scope.sortType = column;
    $scope.trainingAssigns = $filter('orderBy')($scope.trainingAssigns, column, $scope.sortReverse);
  }


  $scope.getDepartmentPositions = function(){
    var deptCode = $location.search().DepartmentCode;
    if(!deptCode)
        alert('Department code not found in query string');
    $rootScope.loading = true;
    $scope.deptPositions = [
        {
            "positionCode": "POS01",
            "positionName": "Position 01",
            "departmentCode": "MM",
            "departmentName": "MM"
        },
        {
            "positionCode": "POS02",
            "positionName": "Position 02",
            "departmentCode": "MM",
            "departmentName": "MM"
        }
    ]

    $interval(function(){
        $rootScope.loading = false;
    }, 1000); 

    if($scope.deptPositions){
        $scope.selectedDeptPos = $scope.deptPositions[0].positionCode;
        $scope.deptPositionChanged($scope.deptPositions[0]);
    }
}
  
  $scope.deptPositionChanged = function(deptPos){
      debugger;
    $scope.getListOfEmployees(deptPos.positionCode);
    $scope.getTrainingAssigns();
  }

  $scope.getListOfEmployees = function(positionCode){
    debugger;
    $rootScope.loading = true;
    $scope.employees = [
        {
            "Number": "10001",
            "FirstName": "Jim",
            "LastName": "smith " + positionCode,
            "Email": "jim.smith@email.com",
            "Company": "xyz",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "SubDepartmentCode": "SS",
            "SubDepartmentName": "SS",
            "JobCode": "pos_code",
            "JobTitle": "Manager",
            "SupervisorNumber": "10005",
            "SupervisorName": "Tin Cook",
            "BuildingCode": "1",
            "BuildingLocation": "111",
            "Active": "Y"
        },
        {
            "Number": "10001",
            "FirstName": "Jim",
            "LastName": "smith",
            "Email": "jim.smith@email.com",
            "Company": "xyz",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "SubDepartmentCode": "SS",
            "SubDepartmentName": "SS",
            "JobCode": "pos_code",
            "JobTitle": "Manager",
            "SupervisorNumber": "10005",
            "SupervisorName": "Tin Cook",
            "BuildingCode": "1",
            "BuildingLocation": "111",
            "Active": "Y"
        }
    ]
    

    $interval(function(){
        $rootScope.loading = false;
    }, 1000); 
  }

  $scope.getTrainingAssigns = function(){
      //$scope.selectedDeptPos
      $rootScope.loading = true;
      $scope.trainingAssigns = [
        {
            "id": "1",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "PositionCode": "pos_code123",
            "PositionName": "position 123",
            "TrainingNumber": "999",
            "prev_doc_number": "prev999",
            "name": "training name 999"
        },
        {
            "id": "2",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "PositionCode": "pos_code123",
            "PositionName": "position 123",
            "TrainingNumber": "635",
            "prev_doc_number": "prev635",
            "name": "training name 635"
        }
      ];

      $scope.trainingAssignsBackup = $scope.trainingAssigns.slice(0);
      $scope.totalItems = $scope.trainingAssigns.length; 
      $rootScope.loading = false;
    
  }

  $scope.getDepartmentPositions();

  $scope.employeeClicked = function(e){
      debugger;
      $location.path('ad-hoc-matrix').search('EmployeeNumber', e.Number);
  }

    $scope.resetConfirm = function(){
        var r = confirm("Clicking OK will reset all changes!");
        if (r == true) {
            $scope.resetDeptAssigns();
        } 
    }

    $scope.saveConfirm = function(){
        var r = confirm("Click OK to save all changes!");
        if (r == true) {
            $scope.saveDeptAssigns();
        } 
    }

});


//iiiiiiiiii
app.controller('positionMatrixModalCtrl', function($scope, $uibModalInstance, $rootScope, $interval, $location, $filter) {
  $scope.newDeptTrainings = [];
  $scope.addListDetailed = [];
  $scope.saveNewDeptTraining = function(){
      angular.forEach($scope.newDeptTrainings, function(value, key){
          if(!$scope.addList && value.isChecked)
              $scope.addList = value.id;
          else if(value.isChecked)
              $scope.addList += ',' + value.id;
     });

      var response = {
          addList: $scope.addList,
          addListDetailed: $scope.addListDetailed
      }
      $uibModalInstance.close(response);
  }
  $scope.cancel = function(){
      $scope.addList = "";
      $uibModalInstance.dismiss('cancel');
  }
  $scope.getNewDeptTrainings = function(){
      $rootScope.loading = true;
      $scope.newDeptTrainings = [
          {
              "id": "2352",
              "majorVersion": "0",
              "number": "123459",
              "name": "Title of doc 12345",
              "prev_doc_number": "Prev 12345"
          },
          {
              "id": "2353",
              "majorVersion": "10",
              "number": "12345",
              "name": "Title of doc 12346",
              "prev_doc_number": "Prev 12346"
          },
          {
              "id": "2354",
              "majorVersion": "1",
              "number": "12345",
              "name": "Title of doc 12347",
              "prev_doc_number": "Prev 12347"
          }
      ]    
      $scope.newDeptTrainingsBackup = $scope.newDeptTrainings.slice(0);
      $scope.totalItems = $scope.newDeptTrainings.length;  
      $interval(function(){
          $rootScope.loading = false;
      }, 1000);    
  }

  $scope.getNewDeptTrainings();

    $scope.sortType     = 'name'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term
  
    $scope.viewby = "5";
    $scope.totalItems = $scope.newDeptTrainings.length;
    $scope.currentPage = 1;
    $scope.itemsPerPage = $scope.viewby;
    $scope.maxSize = 3; //Number of pager buttons to show
    
    $scope.addList = "";

    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };

    $scope.pageChanged = function() {
      console.log('Page changed to: ' + $scope.currentPage);
    };

  $scope.setItemsPerPage = function(num) {
    $scope.itemsPerPage = num;
    $scope.currentPage = 1; //reset to first page
  }

  $scope.searchTriggered = function(){
      $scope.searchFish;
      $scope.getNewDeptTrainingsBackup;
      var keyword = $scope.searchFish.toLowerCase();

      $scope.newDeptTrainings = $scope.newDeptTrainingsBackup.filter(function (da) {
          return (da.name.toLowerCase().indexOf(keyword) > -1 
              || da.toLowerCase().prev_doc_number.indexOf(keyword) > -1
              || da.toLowerCase().number.indexOf(keyword) > -1
              || da.toLowerCase().majorVersion.indexOf(keyword) > -1
          );
      });
      $scope.totalItems = $scope.newDeptTrainings.length; 
      debugger;
  }

  $scope.sortTriggered = function(column){
    $scope.sortReverse = !$scope.sortReverse;
    $scope.sortType = column;
    $scope.newDeptTrainings = $filter('orderBy')($scope.newDeptTrainings, column, $scope.sortReverse);
}


  $scope.addDetailed = function(newDeptObj){
      if(newDeptObj.isChecked){
          var deptCode = $location.search().DepartmentCode;
          var obj = {
              id: newDeptObj.id,
              DepartmentCode: deptCode? deptCode : "querystring missing",
              DepartmentName: "",
              TrainingNumber: newDeptObj.number,
              prev_doc_number: newDeptObj.prev_doc_number,
              name: newDeptObj.name,
              isNew: true
          }
          $scope.addListDetailed.push(obj);

      }
  }
  


});
