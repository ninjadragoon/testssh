app.controller('adhocMatrixCtrl', function($scope, $rootScope, $uibModal, $interval, $location, $http, $filter) {

    $scope.trainingAssigns = [];
    $scope.sortType     = 'name'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term
  
    $scope.viewby = "5";
    $scope.totalItems = $scope.trainingAssigns.length;
    $scope.currentPage = 1;
    $scope.itemsPerPage = $scope.viewby;
    $scope.maxSize = 3; //Number of pager buttons to show
    
    $scope.removalList = "";
    $scope.addList = "";

    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };

    $scope.pageChanged = function() {
      console.log('Page changed to: ' + $scope.currentPage);
    };

  $scope.setItemsPerPage = function(num) {
    $scope.itemsPerPage = num;
    $scope.currentPage = 1; //reset to first page
  }


  $scope.updateRemovalList = function(elem){

      var index = $scope.trainingAssigns.indexOf(elem);
      if (index > -1) {
          $scope.trainingAssigns.splice(index, 1);
          $scope.totalItems = $scope.trainingAssigns.length;
      }

      if(!$scope.removalList)
          $scope.removalList = elem.id;
      else $scope.removalList += "," + elem.id;
      debugger;
  }

  $scope.saveDeptAssigns = function(){
      $rootScope.loading = true;
      var add = $scope.addList;
      var remove = $scope.removalList;
      var employeeNumber = $scope.currentEmployee;

      var data = {
        EmployeeNumber: employeeNumber,
        New: add,
        Remove: remove
     }

     if(add || remove){
        //if there is data only then save.
        $http({
            url: '/api/matrixemployee/',
            dataType: 'json',
            method: 'POST',
            data: data,
            headers: {
                "Content-Type": "application/json"
            }
        
        }).success(function(response){
            $rootScope.loading = false;
            alert('Saved successfull!');

        }).error(function(error){
            $rootScope.loading = false;
            alert('Something went wrong!');
        });
    }



      $interval(function(){
          $rootScope.loading = false;
      }, 1000);  
  }

  $scope.resetDeptAssigns = function(){
      $scope.removalList = "";
      $scope.addList = "";
      $scope.searchFish = "";
      $scope.addListDetailed = [];
      $scope.getTrainingAssigns();
  }

  $scope.addDeptTraining = function(){
      //$scope.addList = "";
      $scope.addListDetailed = [];
      var modalInstance = $uibModal.open({
          templateUrl: 'modal1.html',
          size: 'lg',
          controller: 'adhocMatrixModalCtrl'
        });

        modalInstance.result.then(function (response) {
            //$scope.addList = response.addList; 
            $scope.addListDetailed = response.addListDetailed;
            angular.forEach($scope.addListDetailed, function(value, key){
                var alreadyPresent = false;
                angular.forEach($scope.trainingAssigns, function(value2, key){
                    if(value.id == value2.id)
                      alreadyPresent = true;
                });
                debugger;
                if (!alreadyPresent){
                  $scope.trainingAssigns.push(value);
                  $scope.trainingAssignsBackup.push(value);
                  //
                  if(!$scope.addList)
                    $scope.addList += value.id; 
                  else
                    $scope.addList +=  "," + value.id; 
                  //
                }
            });
            $scope.totalItems = $scope.trainingAssigns.length;

        }, function (dismissed) {
            debugger;
        });
      
  }

  $scope.searchTriggered = function(){
      $scope.searchFish;
      $scope.trainingAssignsBackup;
      var keyword = $scope.searchFish.toLowerCase();

      $scope.trainingAssigns = $scope.trainingAssignsBackup.filter(function (da) {
          return (da.name.toLowerCase().indexOf(keyword) > -1 
              || da.prev_doc_number.toLowerCase().indexOf(keyword) > -1
              || da.TrainingNumber.toLowerCase().indexOf(keyword) > -1
              || da.DepartmentName.toLowerCase().indexOf(keyword) > -1
              || da.DepartmentCode.toLowerCase().indexOf(keyword) > -1
              || da.type.toLowerCase().indexOf(keyword) > -1
          );
      });
      $scope.totalItems = $scope.trainingAssignsBackup.length; 
      debugger;
  }

  $scope.sortTriggered = function(column){
    $scope.sortReverse = !$scope.sortReverse;
    $scope.sortType = column;
    $scope.trainingAssigns = $filter('orderBy')($scope.trainingAssigns, column, $scope.sortReverse);
 }
 
  

  $scope.getTrainingAssigns = function(){
      $rootScope.loading = true;

      $scope.currentEmployee;

      $scope.trainingAssigns = [
        {
       "id": "1",
       "employeeNumber": "12345",
       "employeeName": "Jim Smith",
       "employeeEmail": "jim.smith@email.com",
       "DepartmentCode": "MM",
       "DepartmentName": "MM",
       "PositionCode": "posCode123",
       "PositionName": "Title 123",
       "TrainingNumber": "TrainNum123",
       "BuildingCode": "1",
       "BuildingName": "Building 1",
       "prev_doc_number": "PrevTrainNum123",
       "name": "Name of training TrainNum123",
       "type": "Department"
       },
        {
       "id": "2",
       "employeeNumber": "12345",
       "employeeName": "Jim Smith",
       "employeeEmail": "jim.smith@email.com",
       "DepartmentCode": "MM",
       "DepartmentName": "MM",
       "PositionCode": "posCode123",
       "PositionName": "Title 123",
       "TrainingNumber": "TrainNum1234",
       "BuildingCode": "1",
       "BuildingName": "Building 1",
       "prev_doc_number": "PrevTrainNum1234",
       "name": "Name of training TrainNum1234",
       "type": "Position"
       },
        {
       "id": "3",
       "employeeNumber": "12345",
       "employeeName": "Jim Smith",
       "employeeEmail": "jim.smith@email.com",
       "DepartmentCode": "MM",
       "DepartmentName": "MM",
       "PositionCode": "posCode123",
       "PositionName": "Title 123",
       "TrainingNumber": "TrainNum12345",
       "BuildingCode": "1",
       "BuildingName": "Building 1",
       "prev_doc_number": "PrevTrainNum12345",
       "name": "Name of training TrainNum12345",
       "type": "Location"
       },
        {
       "id": "1",
       "employeeNumber": "12345",
       "employeeName": "Jim Smith",
       "employeeEmail": "jim.smith@email.com",
       "DepartmentCode": "MM",
       "DepartmentName": "MM",
       "PositionCode": "posCode123",
       "PositionName": "Title 123",
       "TrainingNumber": "TrainNum123456",
       "BuildingCode": "1",
       "BuildingName": "Building 1",
       "prev_doc_number": "PrevTrainNum123456",
       "name": "Name of training TrainNum123456",
       "type": "Adhoc"
       },
       
        {
       "id": "1",
       "employeeNumber": "12345",
       "employeeName": "Jim Smith",
       "employeeEmail": "jim.smith@email.com",
       "DepartmentCode": "MM",
       "DepartmentName": "MM",
       "PositionCode": "posCode123",
       "PositionName": "Title 123",
       "TrainingNumber": "TrainNum1234567",
       "BuildingCode": "1",
       "BuildingName": "Building 1",
       "prev_doc_number": "PrevTrainNum1234567",
       "name": "Name of training TrainNum1234567",
       "type": "Adhoc"
       }
       ]
       

      $scope.trainingAssignsBackup = $scope.trainingAssigns.slice(0);
      $scope.totalItems = $scope.trainingAssigns.length; 
      $rootScope.loading = false;
    
  }


  //////
  $scope.currentEmployee = '';
  if($location.search().EmployeeNumber)
    $scope.currentEmployee = $location.search().EmployeeNumber;

  $scope.getEmployees = function(){
    var deptCode = $location.search().DepartmentCode;
    $rootScope.loading = true;
    $scope.employees = [
        {
            "Number": "10001",
            "FirstName": "Joe",
            "LastName": "smith",
            "Email": "jim.smith@email.com",
            "Company": "xyz",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "SubDepartmentCode": "SS",
            "SubDepartmentName": "SS",
            "JobCode": "pos_code",
            "JobTitle": "Manager",
            "SupervisorNumber": "10005",
            "SupervisorName": "Tin Cook",
            "BuildingCode": "1",
            "BuildingLocation": "111",
            "Active": "Y"
        },
        {
            "Number": "10002",
            "FirstName": "Jim",
            "LastName": "smith",
            "Email": "jim.smith@email.com",
            "Company": "xyz",
            "DepartmentCode": "MM",
            "DepartmentName": "MM",
            "SubDepartmentCode": "SS",
            "SubDepartmentName": "SS",
            "JobCode": "pos_code",
            "JobTitle": "Manager",
            "SupervisorNumber": "10005",
            "SupervisorName": "Tin Cook",
            "BuildingCode": "1",
            "BuildingLocation": "111",
            "Active": "Y"
        }
    ];    

    $rootScope.loading = false;
    $scope.employeeChanged();
  }

  $scope.employeeChanged = function(){
    $scope.currentEmployee;
    $scope.getTrainingAssigns();
  }

  $scope.getEmployees();

  $scope.resetConfirm = function(){
    var r = confirm("Clicking OK will reset all changes!");
     if (r == true) {
        $scope.resetDeptAssigns();
     } 
   }

    $scope.saveConfirm = function(){
        var r = confirm("Click OK to save all changes!");
        if (r == true) {
            $scope.saveDeptAssigns();
        } 
    }

});


//iiiiiiiiii
app.controller('adhocMatrixModalCtrl', function($scope, $uibModalInstance, $rootScope, $interval, $location, $filter) {
  $scope.newDeptTrainings = [];
  $scope.addListDetailed = [];
  $scope.saveNewDeptTraining = function(){
      angular.forEach($scope.newDeptTrainings, function(value, key){
          if(!$scope.addList && value.isChecked)
              $scope.addList = value.id;
          else if(value.isChecked)
              $scope.addList += ',' + value.id;
     });

      var response = {
          addList: $scope.addList,
          addListDetailed: $scope.addListDetailed
      }
      $uibModalInstance.close(response);
  }
  $scope.cancel = function(){
      $scope.addList = "";
      $uibModalInstance.dismiss('cancel');
  }
  $scope.getNewDeptTrainings = function(){
      $rootScope.loading = true;
      $scope.newDeptTrainings = [
          {
              "id": "2352",
              "majorVersion": "0",
              "number": "123456",
              "name": "Title of doc 12345",
              "prev_doc_number": "Prev 12345"
          },
          {
              "id": "2353",
              "majorVersion": "10",
              "number": "12345",
              "name": "Title of doc 12346",
              "prev_doc_number": "Prev 12346"
          },
          {
              "id": "2354",
              "majorVersion": "1",
              "number": "12345",
              "name": "Title of doc 12347",
              "prev_doc_number": "Prev 12347"
          }
      ]    
      $scope.newDeptTrainingsBackup = $scope.newDeptTrainings.slice(0);
      $scope.totalItems = $scope.newDeptTrainings.length;  
      $interval(function(){
          $rootScope.loading = false;
      }, 1000);    
  }

  $scope.getNewDeptTrainings();

    $scope.sortType     = 'name'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    $scope.searchFish   = '';     // set the default search/filter term
  
    $scope.viewby = "5";
    $scope.totalItems = $scope.newDeptTrainings.length;
    $scope.currentPage = 1;
    $scope.itemsPerPage = $scope.viewby;
    $scope.maxSize = 3; //Number of pager buttons to show
    
    $scope.addList = "";

    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };

    $scope.pageChanged = function() {
      console.log('Page changed to: ' + $scope.currentPage);
    };

  $scope.setItemsPerPage = function(num) {
    $scope.itemsPerPage = num;
    $scope.currentPage = 1; //reset to first page
  }

  $scope.searchTriggered = function(){
      $scope.searchFish;
      $scope.getNewDeptTrainingsBackup;
      var keyword = $scope.searchFish.toLowerCase();

      $scope.newDeptTrainings = $scope.newDeptTrainingsBackup.filter(function (da) {
          return (da.name.toLowerCase.indexOf(keyword) > -1 
              || da.prev_doc_number.toLowerCase.indexOf(keyword) > -1
              || da.number.toLowerCase.indexOf(keyword) > -1
              || da.majorVersion.toLowerCase.indexOf(keyword) > -1
          );
      });
      $scope.totalItems = $scope.newDeptTrainings.length; 
      debugger;
  }

  $scope.sortTriggered = function(column){
    $scope.sortReverse = !$scope.sortReverse;
    $scope.sortType = column;
    $scope.newDeptTrainings = $filter('orderBy')($scope.newDeptTrainings, column, $scope.sortReverse);
 }


  $scope.addDetailed = function(newDeptObj){
      if(newDeptObj.isChecked){
          var deptCode = $location.search().DepartmentCode;
          debugger;
          var obj = {
              id: newDeptObj.id,
              DepartmentCode: deptCode? deptCode : "querystring missing",
              DepartmentName: "",
              TrainingNumber: newDeptObj.number,
              prev_doc_number: newDeptObj.prev_doc_number,
              name: newDeptObj.name,
              isNew: true,
              type: ""
          }
          $scope.addListDetailed.push(obj);

      }
  }
  


});
