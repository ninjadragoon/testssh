var app = angular.module('app', ['ngRoute', 'ui.bootstrap']);

app.run([ '$rootScope',  function( $rootScope) {
   // $rootScope.loading = false;
}]);

//routes
app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl : 'departmentMatrix/view.html',
            controller  : 'departmentMatrixCtrl'
        })
        .when('/department-matrix', {
            templateUrl : 'departmentMatrix/view.html',
            controller  : 'departmentMatrixCtrl'
        })
        .when('/position-matrix', {
            templateUrl : 'positionMatrix/view.html',
            controller  : 'positionMatrixCtrl'
        })
        .when('/ad-hoc-matrix', {
            templateUrl : 'adhocMatrix/view.html',
            controller  : 'adhocMatrixCtrl'
        })
        .when('/multi-training', {
            templateUrl : 'multiTraining/view.html',
            controller  : 'multiTrainingCtrl'
        })
        .when('/location-matrix', {
            templateUrl : 'locationMatrix/view.html',
            controller  : 'locationMatrixCtrl'
        })
});

app.controller('mainController', function($scope, $rootScope) {
    $scope.message = 'Everyone come and see how good I look!';
    $rootScope.loading = false;
});

